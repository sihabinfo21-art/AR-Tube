# MyTube Android starter

A dark, adaptive Android app starter for phones and tablets, built with Kotlin and Jetpack Compose.

## Important limitations
This is a UI starter, not a finished YouTube client. The sample cards are demo data. The player is intentionally not implemented yet.

YouTube's official APIs/player do not provide a way for a third-party app to remove YouTube ads or grant Premium-only background playback. Do not use this project to bypass ads, access controls, or YouTube restrictions. The next playback step must use an approved YouTube player/integration and follow current YouTube terms.

## Open in Android Studio
1. Install the current stable Android Studio.
2. Choose **Open**, then select this `MyTubeAndroid` folder.
3. Let Gradle sync finish.
4. Connect an Android phone or tablet with USB debugging enabled, or create an emulator.
5. Press **Run**.

## Current starter features
- Dark UI
- Responsive navigation rail on wider screens and bottom navigation on phones
- Search field (filters demo items only)
- Home feed cards
- Video detail placeholder

## Next development steps
- Decide the app name and package ID.
- Add a YouTube Data API key for permitted metadata/search use.
- Implement the approved player flow.
- Add real loading, error states, accessibility, privacy controls, and testing.
