package com.example.mytube

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101010)
private val Card = Color(0xFF202020)
private val Accent = Color(0xFFFF3333)
private val Muted = Color(0xFFAAAAAA)

data class VideoItem(val title: String, val channel: String, val duration: String, val id: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyTubeApp() }
    }
}

@Composable
fun MyTubeApp() {
    var query by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf("Home") }
    var selectedVideo by remember { mutableStateOf<VideoItem?>(null) }
    val demoVideos = listOf(
        VideoItem("Explore the world in 4K", "Travel Studio", "12:40", "ScMzIvxBSi4"),
        VideoItem("Beautiful Quran Recitation", "Quran Channel", "22:06", "placeholder"),
        VideoItem("Learn something new today", "Learning Hub", "08:15", "ysz5S6PUM-U"),
        VideoItem("Music mix for your day", "Music Room", "31:20", "jfKfPfyJRdk")
    )
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Card, primary = Accent, onBackground = Color.White,
        onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            BoxWithConstraints {
                val wide = maxWidth >= 600.dp
                Row(Modifier.fillMaxSize()) {
                    if (wide) {
                        NavigationRail(containerColor = Bg) {
                            listOf("Home", "Shorts", "Subscriptions", "You").forEach { tab ->
                                NavigationRailItem(
                                    selected = selectedTab == tab,
                                    onClick = { selectedTab = tab; selectedVideo = null },
                                    icon = { Icon(tabIcon(tab), null) },
                                    label = { Text(tab, fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                    Column(Modifier.weight(1f).fillMaxHeight()) {
                        if (selectedVideo == null) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("MyTube", fontSize = 25.sp, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f))
                                IconButton(onClick = { }) { Icon(Icons.Default.Cast, "Cast", tint = Color.White) }
                                IconButton(onClick = { }) { Icon(Icons.Default.Notifications, "Notifications", tint = Color.White) }
                            }
                            OutlinedTextField(
                                value = query, onValueChange = { query = it },
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                placeholder = { Text("Search videos") },
                                leadingIcon = { Icon(Icons.Default.Search, null) },
                                singleLine = true,
                                shape = RoundedCornerShape(28.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Accent, unfocusedBorderColor = Muted,
                                    focusedTextColor = Color.White, unfocusedTextColor = Color.White
                                )
                            )
                            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("All", "Music", "Live", "Gaming", "News").forEach {
                                    AssistChip(onClick = { query = if (it == "All") "" else it },
                                        label = { Text(it) })
                                }
                            }
                            LazyColumn(Modifier.weight(1f)) {
                                items(demoVideos.filter { query.isBlank() || it.title.contains(query, true) || it.channel.contains(query, true) }) { video ->
                                    VideoCard(video) { selectedVideo = video }
                                }
                            }
                            if (!wide) {
                                NavigationBar(containerColor = Bg) {
                                    listOf("Home", "Shorts", "Subscriptions", "You").forEach { tab ->
                                        NavigationBarItem(
                                            selected = selectedTab == tab,
                                            onClick = { selectedTab = tab },
                                            icon = { Icon(tabIcon(tab), null) },
                                            label = { Text(tab, fontSize = 10.sp) }
                                        )
                                    }
                                }
                            }
                        } else {
                            Column(Modifier.fillMaxSize()) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { selectedVideo = null }) { Icon(Icons.Default.ArrowBack, "Back") }
                                    Text("Now playing", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                }
                                Box(Modifier.fillMaxWidth().aspectRatio(16f/9f).background(Color.Black), contentAlignment = Alignment.Center) {
                                    Text("Official YouTube player integration\nis the next setup step.",
                                        color = Color.White, lineHeight = 22.sp)
                                }
                                Text(selectedVideo!!.title, Modifier.padding(16.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text(selectedVideo!!.channel, Modifier.padding(horizontal = 16.dp), color = Muted)
                                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    FilledTonalButton(onClick = { }) { Icon(Icons.Default.ThumbUp, null); Spacer(Modifier.width(6.dp)); Text("Like") }
                                    FilledTonalButton(onClick = { }) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(6.dp)); Text("Share") }
                                }
                                Text("Playback must use YouTube's permitted player. Ads and background-play availability are controlled by YouTube.",
                                    Modifier.padding(16.dp), color = Muted, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VideoCard(video: VideoItem, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable { onClick() }.padding(bottom = 18.dp)) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f/9f).padding(horizontal = 12.dp)
            .background(Color(0xFF303030), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PlayCircle, null, tint = Color.White, modifier = Modifier.size(54.dp))
            Text(video.duration, Modifier.align(Alignment.BottomEnd).padding(10.dp)
                .background(Color.Black.copy(alpha = .8f), RoundedCornerShape(4.dp))
                .padding(horizontal = 6.dp, vertical = 3.dp), fontSize = 11.sp)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.AccountCircle, null, tint = Muted, modifier = Modifier.size(42.dp))
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(video.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text("${video.channel}  •  Preview item", color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.MoreVert, null, tint = Muted)
        }
    }
}

@Composable
fun tabIcon(tab: String) = when (tab) {
    "Home" -> Icons.Default.Home
    "Shorts" -> Icons.Default.Bolt
    "Subscriptions" -> Icons.Default.Subscriptions
    else -> Icons.Default.Person
}
